<?php

echo $twig->render('footer.html.twig');
